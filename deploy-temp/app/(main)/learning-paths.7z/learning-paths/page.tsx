import { LearningPathCard3D } from "@/components/3d-effects/learning-path-card-3d"
import { learningPaths } from "@/data/learning-paths"

export default function LearningPathsPage() {
  return (
    <>
      <div className="max-w-4xl mx-auto mb-12 text-center">
        <h1 className="text-4xl font-bold mb-4">Intelligence Analysis Learning Paths</h1>
        <p className="text-xl text-gray-600">
          Learning paths designed by intelligence professionals to help you master different aspects of
          intelligence analysis and operations.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {learningPaths.map((path, index) => (
          <LearningPathCard3D
            key={path.title}
            title={path.title}
            description={path.description}
            image={path.imagePath}
            href={path.path}
            difficulty={path.difficulty}
            topics={path.topicCount}
            estimatedTime={path.estimatedTime}
            intensity="medium"
            index={index}
          />
        ))}
      </div>
    </>
  )
}
