import type { Metadata } from "next"
import { LearningPathTemplate } from "@/components/learning-path-template"

export const metadata: Metadata = {
  title: "Financial Intelligence | Intel Analyst Academy",
  description: "Techniques for tracking and analyzing financial data for intelligence purposes",
}

export default function FinancialIntelligencePage() {
  const topics = [
    {
      title: "Financial Intelligence Fundamentals",
      description: "Core concepts and principles of financial intelligence analysis",
      slug: "financial-intelligence-fundamentals",
      readTime: 30,
    },
    {
      title: "Money Laundering Detection",
      description: "Techniques for identifying and analyzing money laundering activities",
      slug: "money-laundering-detection",
      readTime: 35,
    },
    {
      title: "Financial Network Analysis",
      description: "Methods for mapping and analyzing financial relationships and transactions",
      slug: "financial-network-analysis",
      readTime: 30,
    },
    {
      title: "Cryptocurrency Investigation",
      description: "Specialized techniques for tracking and analyzing cryptocurrency transactions",
      slug: "cryptocurrency-investigation",
      readTime: 40,
    },
    {
      title: "Financial Document Analysis",
      description: "Methods for extracting intelligence from financial records and documents",
      slug: "financial-document-analysis",
      readTime: 25,
    },
    {
      title: "Illicit Finance Indicators",
      description: "Recognizing red flags and indicators of illicit financial activity",
      slug: "illicit-finance-indicators",
      readTime: 20,
    },
    {
      title: "Financial Intelligence Collection",
      description: "Sources and methods for gathering financial intelligence",
      slug: "financial-intelligence-collection",
      readTime: 25,
    },
  ]

  return (
    <LearningPathTemplate pathSlug="financial-intelligence">
      <div className="learning-path-content">
        <h1>Financial Intelligence</h1>
        <p>Master techniques for tracking and analyzing financial data for intelligence purposes. This learning path covers methods for investigating money laundering, analyzing financial networks, and detecting illicit financial activities.</p>
        
        <div className="topics-list">
          {topics.map((topic) => (
            <div key={topic.slug} className="topic-card">
              <h3>{topic.title}</h3>
              <p>{topic.description}</p>
              <span>{topic.readTime} min read</span>
            </div>
          ))}
        </div>
      </div>
    </LearningPathTemplate>
  )
}
