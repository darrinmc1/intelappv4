import type { Metadata } from "next"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { TopicCard } from "@/components/topic-card"
import { WhatsNextCompact } from "@/components/whats-next-compact"

export const metadata: Metadata = {
  title: "Strategic Intelligence Learning Path | Intel Analyst Academy",
  description: "Master the fundamentals of strategic intelligence analysis through our learning path.",
}

const strategicIntelligenceTopics = [
  {
    title: "What is Strategic Intelligence?",
    description: "Understanding the fundamentals of strategic intelligence and its role in long-term planning",
    path: "/topics/what-is-strategic-intelligence",
    image: "/strategic-intelligence-concept.png",
    duration: "15 min read",
    topic: "strategic-intelligence-concept",
  },
  {
    title: "Strategic vs Tactical Intelligence",
    description: "Key differences between strategic and tactical intelligence approaches",
    path: "/topics/strategic-vs-tactical-intelligence",
    image: "/strategic-vs-tactical.png",
    duration: "12 min read",
    topic: "strategic-vs-tactical",
  },
  {
    title: "Strategic Forecasting",
    description: "Methods and techniques for long-term intelligence forecasting",
    path: "/topics/strategic-forecasting",
    image: "/strategic-forecasting.png",
    duration: "20 min read",
    topic: "strategic-forecasting",
  },
  {
    title: "Long-term Threat Assessment",
    description: "Identifying and analyzing threats that may emerge over extended periods",
    path: "/topics/long-term-threat-assessment",
    image: "/long-term-threats-thumb.png",
    duration: "18 min read",
    topic: "long-term-threats",
  },
  {
    title: "Strategic Intelligence Products",
    description: "Types of strategic intelligence products and their applications",
    path: "/topics/strategic-intelligence-products",
    image: "/strategic-intelligence-products-thumb.png",
    duration: "16 min read",
    topic: "strategic-products",
  },
  {
    title: "Briefing Executives",
    description: "Effective communication of strategic intelligence to senior leadership",
    path: "/topics/briefing-executives",
    image: "/briefing-executives-thumb.png",
    duration: "14 min read",
    topic: "briefing-executives",
  },
]

const whatsNextRecommendations = {
  anotherTopic: {
    title: "Tactical Intelligence",
    description: "Learn about short-term, operational intelligence analysis",
    path: "/learning-paths/tactical-intelligence",
  },
  moreLearning: {
    title: "Intelligence Cycle",
    description: "Deep dive into the intelligence analysis process",
    path: "/learning-paths/foundations",
  },
  advancedLearning: {
    title: "Advanced Analytics",
    description: "Master advanced analytical techniques and methodologies",
    path: "/learning-paths/analytical-techniques",
  },
}

export default function StrategicIntelligencePath() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main>
        {/* Hero Section */}
        <section className="relative bg-gradient-to-r from-blue-900 to-blue-700 text-white py-20">
          <div className="absolute inset-0 bg-black/20" />
          <div className="relative container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Strategic Intelligence</h1>
              <p className="text-xl md:text-2xl mb-8 text-blue-100">
                Master long-term intelligence analysis for strategic planning and decision-making at the highest levels
              </p>
              <div className="flex flex-wrap justify-center gap-6 text-blue-100">
                <div className="flex items-center gap-2">
                  <span className="text-sm">⏱️ 8-12 hours</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm">📊 Intermediate</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm">👥 2,847 enrolled</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4 py-16">
          <div className="max-w-6xl mx-auto">
            {/* Overview Section */}
            <section className="mb-16">
              <h2 className="text-3xl font-bold mb-6">Course Overview</h2>
              <div className="prose prose-lg max-w-none">
                <p className="text-lg text-gray-700 mb-4">
                  Strategic intelligence focuses on long-term analysis and forecasting to support high-level
                  decision-making. This path covers the methodologies, tools, and communication techniques
                  essential for strategic intelligence professionals.
                </p>
                <p className="text-lg text-gray-700">
                  You'll learn to analyze complex geopolitical trends, assess long-term threats and opportunities, and
                  present actionable intelligence to senior leadership and policymakers.
                </p>
              </div>
            </section>

            {/* Learning Objectives */}
            <section className="mb-16">
              <h2 className="text-3xl font-bold mb-6">Learning Objectives</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-blue-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-3">Core Concepts</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li>• Understand strategic vs tactical intelligence</li>
                    <li>• Master long-term forecasting techniques</li>
                    <li>• Learn threat assessment methodologies</li>
                  </ul>
                </div>
                <div className="bg-green-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-3">Practical Skills</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li>• Create strategic intelligence products</li>
                    <li>• Brief senior executives effectively</li>
                    <li>• Analyze geopolitical trends</li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Curriculum */}
            <section id="curriculum" className="mb-16">
              <h2 className="text-3xl font-bold mb-8">Curriculum</h2>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {strategicIntelligenceTopics.map((topic, index) => (
                  <TopicCard
                    key={index}
                    title={topic.title}
                    description={topic.description}
                    duration={topic.duration}
                    path={topic.path}
                    topic={topic.topic}
                    image={topic.image}
                  />
                ))}
              </div>
            </section>

            {/* What's Next */}
            <WhatsNextCompact
              anotherTopic={whatsNextRecommendations.anotherTopic}
              moreLearning={whatsNextRecommendations.moreLearning}
              advancedLearning={whatsNextRecommendations.advancedLearning}
            />
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
